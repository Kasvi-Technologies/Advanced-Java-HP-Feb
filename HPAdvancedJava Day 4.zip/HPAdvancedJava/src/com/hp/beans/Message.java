package com.hp.beans;

public class Message {

	public Message() {
		
	}
	public Message(String message) {
		super();
		this.message = message;
	}

	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	public synchronized void produceMessage() {
		
		this.message = "Produced the message..";
		System.out.println("produced the message and waking up the idle thread");
		notify();
	}
	
	public synchronized void consumeMessage() {
		if(this.message == null) {
			System.out.println("Message is null and so wait....");
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("woke up after notify from producer message");
			System.out.println("produced message:" + this.message);
		}
	}
	
}


