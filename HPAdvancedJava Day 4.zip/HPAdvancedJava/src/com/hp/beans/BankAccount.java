package com.hp.beans;

public class BankAccount {
	
	private int amount;

	public int getAmount() {
		return amount;
	}

	//Synchronized method...
	
	public synchronized void insertAmount(int amount) {
		System.out.println(Thread.currentThread().getName() +" insertAmount started.....");
		
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		this.amount = this.amount + amount;
		notify();
		System.out.println(Thread.currentThread().getName() + " insertAmount completed...");
	}
	
	public synchronized void withdrawAmount(int withdrawAmount) {
		
		System.out.println(Thread.currentThread().getName() +" withdrawAmount started.....");
		
		if (withdrawAmount > this.amount) {
			System.out.println("waiting for some one to insert the amount....");
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	
		
		this.amount = this.amount - withdrawAmount;
		System.out.println(Thread.currentThread().getName() + " withdrawAmount completed...");
		
	}

}
