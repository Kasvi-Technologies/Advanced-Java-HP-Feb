package com.hp.test;

public class DeadlockTest {

	public static synchronized void sample () {
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str1 = new String("Str1 Value");
		String str2 = new String("Str1 Value");
		
		Runnable run = () -> {			
			System.out.println("Thread " + Thread.currentThread().getName() + " started..");
			synchronized(str1){
				System.out.println("Thread " + Thread.currentThread().getName() + " obtain the lock on str1");				
				try {
					Thread.sleep(100000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Thread " + Thread.currentThread().getName() + " waiting to lock on str2");	
				synchronized(str2) {
					
				}
			}
			
			System.out.println("Thread " + Thread.currentThread().getName() + " started..");
		};
		
		Runnable run1 = () -> {
			System.out.println("Thread " + Thread.currentThread().getName() + " started..");
			synchronized(str2){
				System.out.println("Thread " + Thread.currentThread().getName() + " obtain the lock on str2");				
				try {
					Thread.sleep(100000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Thread " + Thread.currentThread().getName() + " waiting to lock on str1");	
				synchronized(str1) {
					
				}
			}
			
			System.out.println("Thread " + Thread.currentThread().getName() + " started..");
		};

		Thread t = new Thread (run, "First Thread"); 
		t.setPriority(10);
		
		t.start();
		Thread t1 = new Thread (run1, "Second Thread"); 
		t1.setPriority(5);
		
		t1.start();
		
	}

	
}
