package com.hp.threads;

import java.util.concurrent.BlockingQueue;

import com.hp.beans.Message;

public class BlockingQueueProducer implements Runnable {
	
	public BlockingQueueProducer(BlockingQueue<Message> queue) {
		this.queue = queue;
	}
	private BlockingQueue<Message> queue;
	public void run() {		
		for (int i=1; i<= 100; i++) {
			Message m = new Message("Producing " + i);
			try {
				Thread.sleep(100);
				queue.put(m);  
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
		}
		System.out.println("after 100 elements placing Done");
		Message m = new Message("Done");
		try {
			queue.put(m);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}		
	}
	

}
