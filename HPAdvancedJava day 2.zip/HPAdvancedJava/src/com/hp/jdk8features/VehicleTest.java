package com.hp.jdk8features;

interface Vehicle {
	default int getCost() {
		return 1000;
	}
	void drive();
}

class Car implements Vehicle {
	public void drive() {
		System.out.println("Car drive method...");
	}
}
public class VehicleTest {

	public static void main(String[] args) {
		Vehicle v = new Car();
		System.out.println(v.getCost());
		v.drive();

	}

}
