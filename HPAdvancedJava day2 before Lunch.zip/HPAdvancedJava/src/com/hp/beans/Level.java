package com.hp.beans;

// to define the Constants

interface SampleInterface {
	public void display();
}

public enum Level implements SampleInterface{
	
	High(1) {
		@Override
		public String toLowercase() {
			// TODO Auto-generated method stub
			return "High".toLowerCase();
		}
	}, Medium(2) {
		@Override
		public String toLowercase() {
			// TODO Auto-generated method stub
			System.out.println("medium value printing:" + this.getLevel());
			//Level l = Level.valueOf("Medium");
			return "Medium".toLowerCase();
		}
	}, Low(3) {

		@Override
		public String toLowercase() {
			// TODO Auto-generated method stub
			return "Low".toLowerCase();
		}
		
	}
	;
	public abstract String toLowercase();	
	private int level;
	
	Level(int value){
		this.level = value;
	}
	
	public int getLevel() {
		return level;
	}


	
	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("Using Display:" + getLevel());
		
	}
	
	
}


