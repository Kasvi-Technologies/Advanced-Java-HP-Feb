package com.hp.test;

import java.lang.annotation.Repeatable;

@Repeatable(Schedules.class)
@interface Schedule {
	String dayofTheWeek() default "Mon";
	String dayOfTheMonth() default "1";	
}
