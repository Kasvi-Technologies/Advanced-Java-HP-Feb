package com.hp.jdk8features;

public class SampleImpl implements Sample1, Sample {

	@Override
	public void print(String str) {
		// TODO Auto-generated method stub
		Sample.super.print(str);
		Sample1.super.print(str);
		
		System.out.println("Here onwards child class related business logic..");
		
	}
	
	

}
