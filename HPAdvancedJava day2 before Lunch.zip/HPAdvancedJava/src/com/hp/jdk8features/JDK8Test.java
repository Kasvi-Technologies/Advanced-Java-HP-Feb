package com.hp.jdk8features;

public class JDK8Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Default method Test
		SampleImpl s = new SampleImpl();
		s.print("Hi"); //child class print method will be executed
		
		System.out.println(Sample.isNull("Hello")); //Interface static methods
		System.out.println(Sample.isNull(""));
		
	}

}
