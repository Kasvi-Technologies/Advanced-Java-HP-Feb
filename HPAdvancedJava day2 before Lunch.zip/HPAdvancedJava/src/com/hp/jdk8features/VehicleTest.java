package com.hp.jdk8features;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.hp.beans.Employee;

//If an interface contains only one abstract method , then such a type of interface
//is called Functional Interfaces

@FunctionalInterface
interface Vehicle {
	default int getCost() {
		return 1000;
	}
	public abstract void drive(String str);
}

class Car implements Vehicle {
	public void drive(String str) {
		System.out.println("Car drive method..." + str);
	}
}
public class VehicleTest {

	public static void main(String[] args) {
		Vehicle v = new Car();
		System.out.println(v.getCost());
		v.drive("Driving car..");

		//Anonymous inner class 		
		Vehicle bike = new Vehicle() {
			public void drive(String str) {
				System.out.println("Bike with anonymous innerclass example.");
			}			
		};
		bike.drive("Bike Driving");
		
		//Functional Style approach
		//Lamda expression = 
			// 	Functional interfaces + Anonymous inner classes
		Vehicle truck = (str ) -> {
			System.out.println("truck with functional styleapproach." + str);
			//business logic using str variable..
		};
		truck.drive("truck driving");
		
		//Method reference using object Method
		//utilitymethod implementation pointed by drive method..
		Utility c1 = new Utility();
		Vehicle a = c1::utilitymethod;
		a.drive("first approach of method referece -> object Method");
		a.getCost();
		
		//Method Reference using Static Method..
		//method2 implementation pointed by drive method
		Vehicle a1 = Utility::method2;
		a1.drive("second approach of method referece -> static Method reference");
		a1.getCost();
		
		//Method reference using constructor
		
		Vehicle a2 = Utility::new;
		a2.drive("third approach of method referece -> constructor reference");
		a2.getCost();
		
		
		//Lambda expression Examples...
		
		List<String> strLst = Arrays.asList("Hi", "Hello", "World");		
		strLst.forEach(
				(str) -> {
					//Business logic based on each value of strLst
					System.out.println(str);
				}
		);
		
		//or., if it is only single line., we can use like this
		
		strLst.forEach(str ->System.out.println(str));
		
		//or method reference
		
		strLst.forEach(System.out::println);
		
		//Emp List use the Lambda expression forEach to display the employee objects
		List<Employee> empLst = new ArrayList<Employee>();
		empLst.add(new Employee(1, "Hi", 3434));
		empLst.add(new Employee(2, "Hello", 243));
		empLst.add(new Employee(3, "Abc", 12));
		
		empLst.forEach(System.out::println);
		//or
		empLst.forEach(emp ->System.out.println(emp));
		
		//or 
		empLst.forEach(
				(emp) -> {
					//More Business logic based on each value of emp
					System.out.println(emp);
				}
		);
		
	}
}

class Utility {
	
	public Utility() {
		
	}
	public Utility(String str) {
		System.out.println("in constructor business logic" + str);
	}
	public static void method2(String str) {
		System.out.println("method2 for static method related method reference" + str);
	}
	public void utilitymethod (String str) {
		System.out.println("Utilitymethod for Object method related method reference" + str);
	}
}
