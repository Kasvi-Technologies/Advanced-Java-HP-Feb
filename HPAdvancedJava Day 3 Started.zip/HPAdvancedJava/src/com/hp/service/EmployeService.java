package com.hp.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.hp.beans.Employee;

public class EmployeService<T> {

	//Generic Methods...
	
	private  Map<T, Employee> sampleMap = new HashMap<>();
	public <T> Employee fetchEmployeeBasedOnId(T id) {
		List<Employee> empLst = fetchEmployees();
		return sampleMap.get(id);
		
	}
	
	@SuppressWarnings("unchecked")
	@Deprecated
	public static List<Employee> fetchEmployees(){
		List<Employee> empLst = new ArrayList<Employee>();
		
		Employee emp1 = new Employee(1, "Employee 1" , 100);
		Employee emp2 = new Employee(2, "Employee 2" , 500);
		Employee emp3 = new Employee(3, "Employee 3" , 300);
		Employee emp4 = new Employee(4, "Employee 4" , 200);
		
		empLst.add(emp1);
		empLst.add(emp2);
		empLst.add(emp3);
		empLst.add(emp4);
		
		return empLst;
	}
}
