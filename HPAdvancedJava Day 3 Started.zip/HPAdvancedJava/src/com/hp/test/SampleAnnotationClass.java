package com.hp.test;


@MyAnnotation(value="sample", age=25, colors= {"Red", "Blue"})
public class SampleAnnotationClass {

	@Schedule
	@Schedule(dayofTheWeek="Wed", dayOfTheMonth= "5")
	@MyAnnotation(value="method", colors= {"Yellow", "Black"})
	@MyAnnotation1(value="method1", name="another", age=50, price=25.50)
	public void scheduleMethod() {
		
	}
	
	
	@MyAnnotation(value="method", colors= {"Yellow", "Black"})
	public void add (String a, int b) {
		
	}
	
	public void add () {
		
	}
}


