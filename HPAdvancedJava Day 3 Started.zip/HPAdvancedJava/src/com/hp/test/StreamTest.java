package com.hp.test;

import java.util.Arrays;
import java.util.DoubleSummaryStatistics;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.hp.beans.Device;

public class StreamTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Device d1 = new Device(1, "Hp", "X106", "Laptop", 50000);
		Device d2 = new Device(2, "Lenovo", "X390", "Laptop", 25000);
		Device d3 = new Device(3, "Samsung", "duo", "Mobile", 9000);
		Device d4 = new Device(4, "Samsung", "ABCD", "Tv", 30000);
		Device d5 = new Device(5, "Hp", "XYZ", "Laptop", 15000);
		
		Device d[] = new Device[] {d1, d2, d3, d4, d5};
		
		//first way obtaining stream	
		Stream<Device> deviceStream = Stream.of(d);
		
		//Second Way of Obtaining stream
		List<Device> deviceLst = Arrays.asList(d);
		Stream<Device> deviceLstStream = deviceLst.stream(); 
		
		//Third way of Obtaining Stream
		
		Stream.Builder<Device> deviceStreamBuilder = Stream.builder();
		deviceStreamBuilder.accept(d1);
		deviceStreamBuilder.accept(d2);
		deviceStreamBuilder.accept(d3);
		deviceStreamBuilder.accept(d4);
		deviceStreamBuilder.accept(d5);
		
		Stream<Device> UsingStreamBuilder = deviceStreamBuilder.build();
		
		
		//PartitionBy -> divide your collection into 2 separate lists based on criteria
		System.out.println("After Partition ");
		Map<Boolean, List<Device>> partitionMap 
					= deviceLst.stream().collect(Collectors.partitioningBy(d6 -> d6.getPrice() < 20000));
		
		
		Set<Boolean> keySet = partitionMap.keySet();
		System.out.println(keySet);
		keySet.forEach(b -> System.out.println(b + " " + partitionMap.get(b)));
		
		//GroupBy -> divide your collection into multiple lists based on criteria
		
		Map<String, List<Device>> groupbyTypeDeviceMap = 
				deviceLst.stream().collect(Collectors.groupingBy(Device::getType));
		//deviceLst.stream().collect(Collectors.groupingBy(d10 -> d10.getType()));
		System.out.println("Example of Group By.." + groupbyTypeDeviceMap);
			
		System.out.println("Using For each");
		deviceLst.stream().forEach(System.out::println); // Terminator
		
		//peek() -> intermediatory operations...
		System.out.println("Using Peek....");
		deviceLst.stream().filter(d25 -> d25.getName().equals("Samsung"))
						.peek(System.out::println)
						.collect(Collectors.partitioningBy(d6 -> d6.getPrice() < 20000));
		
		//findAny(), findFirst() methods
		
		Optional<Device> firstDevice = 
				deviceLst.stream().filter(d25 -> d25.getName().equals("Samsung12")).findFirst();
		System.out.println("findFirst:" +  (firstDevice.isPresent()?firstDevice.get():"NoDevice"));
		
		Optional<Device> firstAnyDevice = 
				deviceLst.parallelStream().filter(d25 -> d25.getName().equals("Samsung")).findAny();
		
		System.out.println("findAnyDevice:" +  (firstAnyDevice.isPresent()?firstAnyDevice.get():"NoDevice"));
		
		
		//Statistics -> min, max, avergae, sum
		
		Integer numbers [] = new Integer[] {3,56,78,12,90,12};
		
		List<Integer> numberLst = Arrays.asList(numbers);
		
		//IntStream 
		IntSummaryStatistics statistics = numberLst.stream().mapToInt(x ->x ).summaryStatistics();
		System.out.println("Count:" + statistics.getCount() + " Max:" +statistics.getMax()
							+ "Min:" + statistics.getMin()+ " Average:" + statistics.getAverage()
							+" Total Sum:" + statistics.getSum());
		
		
		//Excercise
		//map device price to mapToDouble and print the summaryStatistics of Device Price
		
		DoubleSummaryStatistics devicePriceStatistics 
						= deviceLst.stream().mapToDouble(d26 -> d26.getPrice()).summaryStatistics();
		
		System.out.println("Device Price total objects:" + devicePriceStatistics.getCount() + 
						" Max:" +devicePriceStatistics.getMax()
						+ "Min:" + devicePriceStatistics.getMin()+ " Average:" + devicePriceStatistics.getAverage()
						+" Total Price:" + devicePriceStatistics.getSum());
		
	}

}
