package com.hp.test;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.hp.beans.Device;

public class StreamTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Device d1 = new Device(1, "Hp", "X106", "Laptop", 50000);
		Device d2 = new Device(2, "Lenovo", "X390", "Laptop", 25000);
		Device d3 = new Device(3, "Samsung", "duo", "Mobile", 9000);
		Device d4 = new Device(4, "Samsung", "ABCD", "Tv", 30000);
		Device d5 = new Device(5, "Hp", "XYZ", "Laptop", 15000);
		
		Device d[] = new Device[] {d1, d2, d3, d4, d5};
		
		//first way obtaining stream	
		Stream<Device> deviceStream = Stream.of(d);
		
		//Second Way of Obtaining stream
		List<Device> deviceLst = Arrays.asList(d);
		Stream<Device> deviceLstStream = deviceLst.stream(); 
		
		//Third way of Obtaining Stream
		
		Stream.Builder<Device> deviceStreamBuilder = Stream.builder();
		deviceStreamBuilder.accept(d1);
		deviceStreamBuilder.accept(d2);
		deviceStreamBuilder.accept(d3);
		deviceStreamBuilder.accept(d4);
		deviceStreamBuilder.accept(d5);
		
		Stream<Device> UsingStreamBuilder = deviceStreamBuilder.build();
		
		
		//PartitionBy -> divide your collection into 2 seperete lists based on criteria
		System.out.println("After Partition ");
		Map<Boolean, List<Device>> partitionMap 
					= deviceLstStream.collect(Collectors.partitioningBy(d6 -> d6.getPrice() < 20000));
		
		
		Set<Boolean> keySet = partitionMap.keySet();
		System.out.println(keySet);
		keySet.forEach(b -> System.out.println(b + " " + partitionMap.get(b)));
		
	}

}
