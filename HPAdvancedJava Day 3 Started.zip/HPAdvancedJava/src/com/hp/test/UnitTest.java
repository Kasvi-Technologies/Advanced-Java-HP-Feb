package com.hp.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.hp.beans.Employee;
import com.hp.service.EmployeService;

public class UnitTest {
	
	
	
	@BeforeClass
	public static void testBeforeClass() {
		System.out.println("Test before class..");
	}
	
	@AfterClass
	public static void testAfterClass() {
		System.out.println("Test after class..");
	}
	
	@Before
	public void testBefore() {
		System.out.println("Test before..");
	}
	
	@After
	public void testAfter() {
		System.out.println("Test After..");
	}
	
	
	@Test
	public void testfetchEmployees() {
		//System.out.println("TestFetchEmployees.............");
		EmployeService service = new EmployeService();
		List<Employee> empLst = service.fetchEmployees();
		assertNotNull(empLst);
		
		assertEquals(4, empLst.size());
		
	}
	
	@Test(expected=Exception.class)
	public void testAdd() {
		try {
			assertEquals(3, add(2,1));
			assertEquals(3, add(1,2));
			assertEquals(4, add(2,2));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	@Ignore
	@Test
	public void testMultiply() {
		assertEquals(2, multiply(2,1));
		
		
	}
	
	public int multiply (int a , int b) {
		return a*b;
	}
	public int add (int a , int b) throws Exception {
		
		if (a < 0 && b< 0) {
			throw new Exception("Should not be less than 0");
		}
		if (a > b) {
			return a+b;
		} else if (a >b) {
			return a+b;
		}
		return a+b;
		
	}
}
