package com.hp.test;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE})
@interface MyAnnotation1 {

	String name() default "sample";
	String value();
	int age() default 10;
	String[] roles() default {"Admin", "User"};
	String[] behaviour() default { "asdasd", "asdsadsa"};
	double price() default 20.0;
	
}
