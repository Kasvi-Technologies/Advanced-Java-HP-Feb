package com.hp.test;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.hp.beans.Employee;

public class UnitTest1 {

	@Test
	public void testAssertions () {
		
		String str = null;
		
		assertNull(str);
		
		Employee emp = new Employee();
		assertNotNull(emp);
		
		Employee emp1 = emp;
		
		assertSame(emp1, emp); // both refer the same instance or not
		assertNotSame(new Employee(), emp); // both should not refer the same object
		assertNotSame(new String("Hi"), "Hi");
		
		assertEquals("Hi", "Hi");
		
		assertArrayEquals(new int[] {1, 2}, new int[] {1, 2});
		
		int a =100;
		assertTrue(a> 10);
		
		assertFalse(a< 10);
		
		
	}
}
