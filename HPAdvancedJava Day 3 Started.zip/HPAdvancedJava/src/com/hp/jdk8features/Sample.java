package com.hp.jdk8features;

interface Sample1 {
	default void print(String str) {
		System.out.println("using smaple 1 interface");
	}
}

public interface Sample {
	
	default void print(String str) {
		System.out.println("Interface print method....");
		if(!isNull(str))
			System.out.println("Interface sample data.." + str);
	}	
	//Static methods are mainly used for utility methods
	//these methods will not be overridden to child class
	
	static boolean isNull(String str) {
		
		return str==null? true: "".equals(str)? true: false;
	}
}
