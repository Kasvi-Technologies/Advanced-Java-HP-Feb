package com.hp.beans;

import java.util.List;

//public class ArrayList<Employee>

// E, T, K, V, S, U e.t.c

public  <E> void display (E[] items){
	
}

public static <E> boolean validate(List<E> items, E item) {
	
	items.get(0).equals(item);
	
	
	return true;
}

public class GenericExample<T > {

	private T val;

	//private S val1;
	
	public T getVal() {
		return val;
	}

	public void setVal(T val) {
		this.val = val;
	}
	
	
}
