package com.hp.genericsex;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.hp.beans.CustomGenericMap;
import com.hp.beans.Employee;
import com.hp.beans.GenericExample;
import com.hp.service.EmployeService;

public class WithOutGenericsEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List valuesList = new ArrayList();
		
		valuesList.add(10);
		valuesList.add("Sample");
		
		valuesList.add(23.80);
		
		Iterator itr = valuesList.iterator();
		
		while (itr.hasNext()) {
			Object obj = itr.next();
			System.out.println(obj);
		}
		
		List<String> strLst = new ArrayList<String>();
		
		strLst.add("sample1");
		//strLst.add(100); //compile time error., 
		strLst.add("Sample2");
		
		Iterator<String> strLstItr = strLst.iterator();
		
		while (strLstItr.hasNext()) {
			String obj = strLstItr.next();
			System.out.println(obj);
		}
		
		
		List<Employee> empLst = new EmployeService().fetchEmployees();
		
		Iterator<Employee> empLstItr = empLst.iterator();
		
		while (empLstItr.hasNext()) {
			Employee emp = empLstItr.next();
			System.out.println(emp);
		}
		
		//enhanced for loop
		
		for(Employee emp : empLst) {
			//Business logic based on emp
			System.out.println(emp);
		}
		
		GenericExample<String> genericExample = new GenericExample<String>();
		genericExample.setVal("Sample");
		
		GenericExample<Integer> genericExample1 = new GenericExample<Integer>();
		genericExample1.setVal(10);
		
		
		GenericExample<Employee> genericExample2 = new GenericExample<Employee>();
		genericExample2.setVal(new Employee());
		
		
		//Type Inference or Diamond Operator -> from JDk 7 onwards
		GenericExample<Employee> genericExample3 = new GenericExample<>();
		genericExample3.setVal(new Employee());
		
		
		//
		//Map<Integer, Employee> empMap = new HashMap<Integer, Employee>();
		//or
		Map<Integer, Employee> empMap = new HashMap<>();
		empMap.put(1, new EmployeService().fetchEmployees().get(0));
		empMap.put(2, new EmployeService().fetchEmployees().get(1));
		empMap.put(3, new EmployeService().fetchEmployees().get(2));
		empMap.put(4, new EmployeService().fetchEmployees().get(3));
		
		
		
		CustomGenericMap<Integer, Employee> customMap = new 
												CustomGenericMap<>();
		customMap.setCustomMap(1, new EmployeService().fetchEmployees().get(0));
		customMap.setCustomMap(2, new EmployeService().fetchEmployees().get(1));
		customMap.setCustomMap(3, new EmployeService().fetchEmployees().get(2));
		customMap.setCustomMap(4, new EmployeService().fetchEmployees().get(3));
		
		CustomGenericMap<Integer, List<Employee>> customMap1 = new 
								CustomGenericMap<>();
		
		
	}
	
	

}
