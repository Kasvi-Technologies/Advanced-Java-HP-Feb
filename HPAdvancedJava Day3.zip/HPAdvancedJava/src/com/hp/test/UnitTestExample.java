package com.hp.test;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class UnitTestExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Result result = JUnitCore.runClasses(UnitTest.class);
		
		System.out.println("Failure count:" + result.getFailureCount());
		
		for (Failure failure : result.getFailures()) {
			
			System.out.println(failure.getMessage());
			
		}
		
		System.out.println("Successfull:" + result.wasSuccessful());
		
	}

}
