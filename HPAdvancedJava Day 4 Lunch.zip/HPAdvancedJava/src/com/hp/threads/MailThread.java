package com.hp.threads;

import com.hp.beans.Employee;

public class MailThread extends Thread {

	private Employee employee;
	
	public MailThread(Employee employee) {
		this.employee = employee;
	}
	
	public void run () {
		System.out.println("Mail Thread initiated..." + Thread.currentThread().getName());
		
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		employee.sendMail();
		
		System.out.println("Mail Thread completed....." + Thread.currentThread().getName());
		
	}
}
