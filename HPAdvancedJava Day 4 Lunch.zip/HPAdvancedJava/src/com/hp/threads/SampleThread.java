package com.hp.threads;

public class SampleThread extends Thread {

	@Override
	public void run() {
		//Business logic which we have written will be executed in back ground (Asynchronous)
		System.out.println("Sample Thread run method started for the thread: " + Thread.currentThread().getName());
		for (int i = 1; i <20 ; i++) {
			System.out.println("Transfering employee " + i + " salary");
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		System.out.println("Sample Thread run method completed for the thread:" + Thread.currentThread().getName());
	}
	
}
