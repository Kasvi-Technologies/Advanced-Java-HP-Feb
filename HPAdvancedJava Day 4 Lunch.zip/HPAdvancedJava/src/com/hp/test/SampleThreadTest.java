package com.hp.test;

import com.hp.threads.SampleThread;

public class SampleThreadTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("main method started...");
		SampleThread sampleThread = new SampleThread();
		sampleThread.setName("SampleThread");
		
		SampleThread sampleThread1 = new SampleThread();
		sampleThread1.setName("SampleThread1");
		
		sampleThread.start(); //This start will call run method in the background and executes the run method logic
		sampleThread1.start();
		
		//main method can be completed before thread., since thread is running in background
		
		try {
			//sampleThread.join();
			sampleThread1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Main method completed....");
	}

}
