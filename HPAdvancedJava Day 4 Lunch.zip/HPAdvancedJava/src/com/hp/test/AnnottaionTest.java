package com.hp.test;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

public class AnnottaionTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Reflection
		
		Annotation classAnnotations[] = SampleAnnotationClass.class.getAnnotations();
		
		System.out.println("annotation size:" + classAnnotations.length);
		for (Annotation classAnotation : classAnnotations) {
			
			if (classAnotation instanceof MyAnnotation) {
				MyAnnotation myAnnotation = (MyAnnotation)  classAnotation;
				
				System.out.println(myAnnotation.name() + " " + myAnnotation.value() 
						+ " " + myAnnotation.age() + " " + myAnnotation.colors());
				
				if (myAnnotation.name().equals("sample") &&
						myAnnotation.value().equals("sample") &&
						myAnnotation.age() == 25) {
					//Perform runtime business logic based on your annotation.....
					
				}
				
			}
			
		}
		
		//Method level annotation..
		
		try {
			Annotation methodAnnotations[] = SampleAnnotationClass.class
							.getMethod("add", 
									new Class[] {String.class, Integer.class})
							.getAnnotations();
			//Method method[] = SampleAnnotationClass.class.getMethods();
		System.out.println("annotation size:" + methodAnnotations.length);
		for (Annotation methodAnotation : methodAnnotations) {
			
			if (methodAnotation instanceof MyAnnotation) {
				MyAnnotation myAnnotation = (MyAnnotation)  methodAnotation;
				
				System.out.println(myAnnotation.name() + " " + myAnnotation.value() 
						+ " " + myAnnotation.age() + " " + myAnnotation.colors());
				
				if (myAnnotation.name().equals("sample") &&
						myAnnotation.value().equals("method") &&
						myAnnotation.age() == 10) {
					//Perform runtime business logic based on your annotation.....
					System.out.println("doing method business logic., if annotation found");
				}
				
			}
			
		}
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
