package com.hp.test;

import com.hp.beans.BankAccount;

public class BankAccountTest {

	public static void main(String[] args) throws InterruptedException {
		
		BankAccount bankAccount = new BankAccount();
		
		BankAccount bankAccount1 = new BankAccount();
		
		//initial value is 1000 for amount		
		//span multiple requests ., trying to access the shared resource
		Runnable run = () -> {
			System.out.println("first request");
			bankAccount.insertAmount(200);
			
			System.out.println("first request completed");
		};
		Runnable run1 = () -> {
			System.out.println("second request");
			bankAccount1.withdrawAmount(500);
			
			System.out.println("second request completd..");
		};		
		
		Thread t = new Thread(run, "Insert Thread");
		Thread t1 = new Thread(run1 , "Withdraw Thread");		
		
		t.start();
		t1.start();
		
		
		
		//System.out.println("Threads completed: final amount is:" + bankAccount.getAmount());
	}

}
