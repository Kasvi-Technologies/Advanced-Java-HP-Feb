package com.hp.jdk8features;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.hp.beans.Employee;

public class JDk8Streams {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Employee> empLst = new ArrayList<Employee>();
		empLst.add(new Employee(1, "Hi", 3434));
		empLst.add(new Employee(2, "Hello", 243));
		empLst.add(new Employee(3, "Abc", 12));
		
		empLst.stream().filter(emp -> emp.getSalary() >2000)
								.forEach(emp -> System.out.println(emp));
		
		
		List<Employee> filteredList = empLst.stream()
											.filter(emp -> emp.getSalary() >2000)
											.collect(Collectors.toList());
		
		long filteredCount = empLst.stream().filter(emp -> emp.getSalary() >2000)
											.count();
		
		System.out.println(filteredCount);
		
		
		Set<Integer> empIds = empLst.stream().filter(emp -> emp.getSalary() >2000)
											.map(emp -> emp.getId())
											.collect(Collectors.toSet());
		
		Set<Integer> empIds1 = empLst.stream().filter(emp -> emp.getSalary() >2000)
											  .map(Employee::getId)
											  .collect(Collectors.toSet());
		
		
		
	}
	

}
