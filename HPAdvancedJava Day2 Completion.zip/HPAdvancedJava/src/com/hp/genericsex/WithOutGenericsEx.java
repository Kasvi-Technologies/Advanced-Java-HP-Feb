package com.hp.genericsex;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.hp.beans.CustomGenericMap;
import com.hp.beans.Employee;
import com.hp.beans.GenericExample;
import com.hp.service.EmployeService;

public class WithOutGenericsEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List valuesList = new ArrayList();
		
		valuesList.add(10);
		valuesList.add("Sample");
		
		valuesList.add(23.80);
		
		Iterator itr = valuesList.iterator();
		
		while (itr.hasNext()) {
			Object obj = itr.next();
			System.out.println(obj);
		}
		
		List<String> strLst = new ArrayList<String>();
		
		strLst.add("sample1");
		//strLst.add(100); //compile time error., 
		strLst.add("Sample2");
		
		Iterator<String> strLstItr = strLst.iterator();
		
		while (strLstItr.hasNext()) {
			String obj = strLstItr.next();
			System.out.println(obj);
		}
		
		
		List<Employee> empLst = new EmployeService().fetchEmployees();
		
		Iterator<Employee> empLstItr = empLst.iterator();
		
		while (empLstItr.hasNext()) {
			Employee emp = empLstItr.next();
			System.out.println(emp);
		}
		
		//enhanced for loop
		
		for(Employee emp : empLst) {
			//Business logic based on emp
			System.out.println(emp);
		}
		
		GenericExample<String> genericExample = new GenericExample<String>();
		genericExample.setVal("Sample");
		
		GenericExample<Integer> genericExample1 = new GenericExample<Integer>();
		genericExample1.setVal(10);
		
		
		GenericExample<Employee> genericExample2 = new GenericExample<Employee>();
		genericExample2.setVal(new Employee());
		
		
		//Type Inference or Diamond Operator -> from JDk 7 onwards
		GenericExample<Employee> genericExample3 = new GenericExample<>();
		genericExample3.setVal(new Employee());
		
		
		//
		//Map<Integer, Employee> empMap = new HashMap<Integer, Employee>();
		//or
		Map<Integer, Employee> empMap = new HashMap<>();
		empMap.put(1, new EmployeService().fetchEmployees().get(0));
		empMap.put(2, new EmployeService().fetchEmployees().get(1));
		empMap.put(3, new EmployeService().fetchEmployees().get(2));
		empMap.put(4, new EmployeService().fetchEmployees().get(3));
		
		
		
		CustomGenericMap<Integer, Employee> customMap = new 
												CustomGenericMap<>();
		customMap.setCustomMap(1, new EmployeService().fetchEmployees().get(0));
		customMap.setCustomMap(2, new EmployeService().fetchEmployees().get(1));
		customMap.setCustomMap(3, new EmployeService().fetchEmployees().get(2));
		customMap.setCustomMap(4, new EmployeService().fetchEmployees().get(3));
		
		CustomGenericMap<Integer, List<Employee>> customMap1 = new 
								CustomGenericMap<>();
		
		Integer[] intArray = {1, 2, 3};
		
		WithOutGenericsEx withOutGenericsEx = new WithOutGenericsEx();
		withOutGenericsEx.display(intArray);
		
		String[] strArray = {"asd", "ad", "asda"};
		withOutGenericsEx.display(strArray);
		
		List<Integer> intLst = Arrays.asList(1, 2,3,4, 5);
		List<Double> doubleLst = Arrays.asList(100.00, 200.23,312.34,400.23, 500.13);
		List<String> strLst1 = Arrays.asList("sample1", "sample2", "sample3");
		System.out.println(withOutGenericsEx.searchInList(intLst , 3));
		System.out.println(withOutGenericsEx.searchInList(doubleLst , 3.8));
	//	System.out.println(withOutGenericsEx.searchInList(strLst1 , "sample2"));
		
	}
	//upper bounded types 
	//searchItem in List	
		public <E extends Number> boolean searchInList (List<E> items, E item) {			
			for (E element: items) {
				if(element.equals(item)) {
					return true;
				}
			}
			return false;
		}
		
		//Lower bounded types
		
		public void addInList (List<? super Integer> items, int item) {			
			
			items.add(item);
		}
	
		
	public <E> void display(E[] items ) {
		
		for (E element: items) {
			System.out.println(element);
		}
	}
	
	//Type Erasures.. 
	
	// .class file
//	public void display(Object[] items ) {
//		
//		for (Object element: items) {
//			System.out.println(element);
//		}
//	}
	

}
