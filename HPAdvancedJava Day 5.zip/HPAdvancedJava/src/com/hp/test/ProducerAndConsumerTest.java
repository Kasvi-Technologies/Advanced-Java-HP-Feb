package com.hp.test;

import com.hp.beans.Message;

public class ProducerAndConsumerTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Message message = new Message();
		
		Runnable consumerun = () -> {
			
			message.consumeMessage();
		};
		
		Runnable producerun1 = () -> {
			
			message.produceMessage();
		};
		
		Thread t = new Thread(consumerun, "Consumer Thread");
		Thread t1 = new Thread(producerun1, "Producer Thread");
		
		t.start();
		t1.start();
	}

}
