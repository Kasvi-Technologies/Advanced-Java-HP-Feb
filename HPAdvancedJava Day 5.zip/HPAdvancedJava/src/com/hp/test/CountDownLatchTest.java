package com.hp.test;

import java.util.concurrent.CountDownLatch;

public class CountDownLatchTest {

	public static void main (String[] args) {
		
		CountDownLatch cl = new CountDownLatch(3);		
		Runnable run = ()->{
			System.out.println("awaiting for couunt down  to be called");
			try {
				cl.await();
				
				System.out.println("woke up after completion of 3 count downs...");
			} catch (InterruptedException e) {
			}
		};
		Runnable run1 = ()->{
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
			}
			System.out.println("countdown " + cl.getCount());
			cl.countDown(); 
			System.out.println("countdown " + cl.getCount());
			cl.countDown(); 
			System.out.println("countdown " + cl.getCount());
			cl.countDown(); 
			System.out.println("all count downs done..");
		};
		
		Thread t = new Thread(run);
		t.start();
		//t.interrupt();
		new Thread(run1).start();
		
		
	}
}
