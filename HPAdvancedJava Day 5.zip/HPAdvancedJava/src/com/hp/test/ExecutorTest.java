package com.hp.test;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import com.hp.beans.Employee;

public class ExecutorTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Executors are mainly to run the threads., no need to specify start
		//It will accept only runnable and callable interfaces
		
		//Pool of Threads can be created by Executors..
		
		Runnable run1 = () -> {
			System.out.println("run1 method..." + Thread.currentThread().getName());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		};
		Runnable run2 = () -> {
			System.out.println("run2 method..." + Thread.currentThread().getName());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		};
		Runnable run3 = () -> {
			System.out.println("run3 method..." + Thread.currentThread().getName());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		};
		
		Executors.newSingleThreadExecutor();
		
		ScheduledExecutorService sService = Executors.newScheduledThreadPool(10);
				
//		sService.scheduleAtFixedRate(run1, 100, 200, TimeUnit.SECONDS);
//		sService.scheduleAtFixedRate(run2, 100, 200, TimeUnit.SECONDS);
//		sService.scheduleWithFixedDelay(run3, 200, 500, TimeUnit.SECONDS);
		
		
		
		ExecutorService service = Executors.newFixedThreadPool(2);
		
		Future f = service.submit(run1);
		service.execute(run2);
		service.execute(run3);
		
		EmployeeCallable c = new EmployeeCallable(1);
		
			Future<Employee> callableReturn = service.submit(c);
		
		
		//get() method returns value from run() or call method
		try {
			System.out.println(f.get()); // blocking call
			
				System.out.println(callableReturn.get());
			
		} catch (Exception e) {
			System.out.println("exception caught:" + e.getMessage());
		}
		service.shutdown();
	System.out.println("completed....");
		
		
	}	
}

class EmployeeCallable implements Callable<Employee> {
	private int i;
	public EmployeeCallable(int i) {
		this.i = i;
	}
	@Override
	public Employee call() throws Exception {
		System.out.println("..business logic to perform in call and return employee based on busines logic");
		if (i==5) throw new Exception("Exception....");
		return new Employee(1, "sdasd", 453);
	}	
}
