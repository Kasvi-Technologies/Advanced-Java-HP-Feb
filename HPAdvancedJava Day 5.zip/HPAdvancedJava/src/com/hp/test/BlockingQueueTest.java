package com.hp.test;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import com.hp.beans.Message;
import com.hp.threads.BlockingQueueConsumer;
import com.hp.threads.BlockingQueueProducer;

public class BlockingQueueTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BlockingQueue<Message> queue = new ArrayBlockingQueue<>(10);
		
		BlockingQueueProducer producer = new BlockingQueueProducer(queue);
		BlockingQueueConsumer consumer = new BlockingQueueConsumer(queue);
		
		new Thread(consumer).start();
		new Thread(producer).start();
		
		
	}

}
