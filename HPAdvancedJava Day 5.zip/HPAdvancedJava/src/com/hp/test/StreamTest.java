package com.hp.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.DoubleSummaryStatistics;
import java.util.IntSummaryStatistics;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.Spliterator;
import java.util.TreeSet;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.hp.beans.Device;

public class StreamTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Device d1 = new Device(1, "Hp", "X106", "Laptop", 50000);
		Device d2 = new Device(2, "Lenovo", "X390", "Laptop", 25000);
		Device d3 = new Device(3, "Samsung", "duo", "Mobile", 9000);
		Device d4 = new Device(4, "Samsung", "ABCD", "Tv", 30000);
		Device d5 = new Device(5, "Hp", "XYZ", "Laptop", 15000);
		
		Device d[] = new Device[] {d1, d2, d3, d4, d5};
		
		//first way obtaining stream	
		Stream<Device> deviceStream = Stream.of(d);
		
		//Second Way of Obtaining stream
		List<Device> deviceLst = Arrays.asList(d);
		Stream<Device> deviceLstStream = deviceLst.stream(); 
		
		//Third way of Obtaining Stream
		
		Stream.Builder<Device> deviceStreamBuilder = Stream.builder();
		deviceStreamBuilder.accept(d1);
		deviceStreamBuilder.accept(d2);
		deviceStreamBuilder.accept(d3);
		deviceStreamBuilder.accept(d4);
		deviceStreamBuilder.accept(d5);
		
		Stream<Device> UsingStreamBuilder = deviceStreamBuilder.build();
		
		
		//PartitionBy -> divide your collection into 2 separate lists based on criteria
		System.out.println("After Partition ");
		Map<Boolean, List<Device>> partitionMap 
					= deviceLst.stream().collect(Collectors.partitioningBy(d6 -> d6.getPrice() < 20000));
		
		
		Set<Boolean> keySet = partitionMap.keySet();
		System.out.println(keySet);
		keySet.forEach(b -> System.out.println(b + " " + partitionMap.get(b)));
		
		//GroupBy -> divide your collection into multiple lists based on criteria
		
		Map<String, List<Device>> groupbyTypeDeviceMap = 
				deviceLst.stream().collect(Collectors.groupingBy(Device::getType));
		//deviceLst.stream().collect(Collectors.groupingBy(d10 -> d10.getType()));
		System.out.println("Example of Group By.." + groupbyTypeDeviceMap);
			
		System.out.println("Using For each");
		deviceLst.stream().forEach(System.out::println); // Terminator
		
		//peek() -> intermediatory operations...
		System.out.println("Using Peek....");
		deviceLst.stream().filter(d25 -> d25.getName().equals("Samsung"))
						.peek(System.out::println)
						.collect(Collectors.partitioningBy(d6 -> d6.getPrice() < 20000));
		
		//findAny(), findFirst() methods
		
		Optional<Device> firstDevice = 
				deviceLst.stream().filter(d25 -> d25.getName().equals("Samsung12")).findFirst();
		System.out.println("findFirst:" +  (firstDevice.isPresent()?firstDevice.get():"NoDevice"));
		
		Optional<Device> firstAnyDevice = 
				deviceLst.parallelStream().filter(d25 -> d25.getName().equals("Samsung")).findAny();
		
		System.out.println("findAnyDevice:" +  (firstAnyDevice.isPresent()?firstAnyDevice.get():"NoDevice"));
		
		
		//Statistics -> min, max, avergae, sum
		
		Integer numbers [] = new Integer[] {3,56,78,12,90,12};
		
		List<Integer> numberLst = Arrays.asList(numbers);
		
		//IntStream 
		IntSummaryStatistics statistics = numberLst.stream().mapToInt(x ->x ).summaryStatistics();
		System.out.println("Count:" + statistics.getCount() + " Max:" +statistics.getMax()
							+ "Min:" + statistics.getMin()+ " Average:" + statistics.getAverage()
							+" Total Sum:" + statistics.getSum());
		
		
		//Excercise
		//map device price to mapToDouble and print the summaryStatistics of Device Price
		
		DoubleSummaryStatistics devicePriceStatistics 
						= deviceLst.stream().mapToDouble(d26 -> d26.getPrice()).summaryStatistics();
		
		System.out.println("Device Price total objects:" + devicePriceStatistics.getCount() + 
						" Max:" +devicePriceStatistics.getMax()
						+ "Min:" + devicePriceStatistics.getMin()+ " Average:" + devicePriceStatistics.getAverage()
						+" Total Price:" + devicePriceStatistics.getSum());
		
		//Stream Specializers (same like Summary Statistics)
		//IntStream, DoubleStream, LongStream
		
		double sum = deviceLst.stream().mapToDouble(x -> x.getPrice()).sum();
		deviceLst.stream().mapToDouble(x -> x.getPrice()).average();
		
		//Sort the collection using Streams.
		//name based Sorting
		List<Device> sortedDeviceLst = 
								deviceLst.stream().sorted((d30, d31) -> d30.getName().compareTo(d31.getName()))
									.collect(Collectors.toList());
		System.out.println(sortedDeviceLst);
		
		//Id based Sorting
		deviceLst.stream().sorted((d30, d31) -> d30.getId() - d31.getId() )
						.collect(Collectors.toList());
		//Double type
		List<Device> sortedDevicePriceLst = 
						deviceLst.stream().sorted((d30, d31) -> Double.compare(d30.getPrice(),d31.getPrice()) )
									.collect(Collectors.toList());
		System.out.println(sortedDevicePriceLst);
		
		
		//or., generic for all
		
		deviceLst.stream().sorted(Comparator.comparing(Device::getPrice)).collect(Collectors.toList());
		
		//min and max
		Device minPriceDevice = deviceLst.stream().min(Comparator.comparing(Device::getPrice)).get();
		System.out.println("minPriceDevice:" + minPriceDevice);
		
		Device maxPriceDevice = deviceLst.stream().max(Comparator.comparing(Device::getPrice)).get();
		System.out.println("maxPriceDevice:" + maxPriceDevice);
		
		//anyMatch, allMatches, noneMatch methods
		boolean flag = deviceLst.stream().anyMatch(d100 -> d100.getName().equals("Abcd")); // false
		boolean flag1 = deviceLst.stream().anyMatch(d100 -> d100.getName().equals("Hp")); //true
		
		boolean flag2 = deviceLst.stream().allMatch(d100 -> d100.getName().equals("Hp")); //false
		
		boolean flag3 = deviceLst.stream().noneMatch(d100 -> d100.getName().equals("Abcd")); //true
		
		
		//toArray() -> convert list stream into an array
		
		Device[] devices = deviceLst.stream().toArray(Device[]::new);
		
		//reduce operation -> collects all elements and performs the specified computation operation
		//0.0 is starting value to add sum for first element
		
		double sumPrice = deviceLst.stream().mapToDouble(d200-> d200.getPrice())
							.reduce(0.0, Double::sum);
		
		
		//forEachOrdered -> display all values in the same order which represented in the stream
		
		deviceLst.parallelStream().forEach(System.out::println); // random order
		deviceLst.parallelStream().forEachOrdered(System.out::println); // same order which was in stream
		
		//forEachRemaining ., no need to use while loop ,  hasNext and next methods in Iterator -> collection API improvements
		Iterator<Device> deviceItr = deviceLst.iterator();
		
		deviceItr.forEachRemaining(System.out::println);
		
//		while(deviceItr.hasNext()) {
//			Device d21 = deviceItr.next();
//			System.out.println(d21);
//		}
				
		//removeIf method ., Collection API Improvements
		deviceLst.removeIf(device100 -> device100.getPrice()==5000);
		
		//Infinite Streams 
		//generate and iterate methods in Streams are used to create infinite Streams
		
		Stream<String> strStream = Stream.generate(()-> "Sample").limit(2);
		
		Stream<Device> empStream = Stream.generate(()-> new Device()).limit(10);
		
		Stream<Integer> intStream = Stream.iterate(1, i -> i+1).skip(10).limit(50);
		
		System.out.println("IntStream");
		intStream.forEach(System.out::println);
		
		Stream<Integer> evenStream = Stream.iterate(2, n -> n + 2 ).skip(10).limit(50);
		System.out.println("evenStream");
		evenStream.forEach(System.out::println);
		
		//Split Iterators
		
		Spliterator<Device> spliterator = deviceLst.spliterator();
		
		
		int a = spliterator.characteristics();
		
		System.out.println(Spliterator.ORDERED ==a);
		
		System.out.println("List characteristics" + a);
		
		System.out.println("Ordered:" + spliterator.hasCharacteristics(Spliterator.ORDERED));
		System.out.println("Sized:" + spliterator.hasCharacteristics(Spliterator.SIZED));
		System.out.println("Sorted:" + spliterator.hasCharacteristics(Spliterator.SORTED));
		System.out.println("Sorted:" + spliterator.hasCharacteristics(Spliterator.DISTINCT));
		
		System.out.println("estimatdSize:"+spliterator.estimateSize());
		spliterator.forEachRemaining(System.out::println);
		
		//List<Device> deviceLst10 = new ArrayList<Device>();
		Spliterator<Device> spliterator1 = deviceLst.spliterator();
		
		Spliterator<Device> deviceLstAfterSplit = spliterator1.trySplit();
		
		System.out.println("After split..");
		
		deviceLstAfterSplit.forEachRemaining(System.out::println);
		
		System.out.println("remaining elements in original spliterator");
		spliterator1.forEachRemaining(System.out::println);
		
		Set<String> set = new TreeSet<String>(Comparator.reverseOrder());
		Spliterator<String> setSplIterator = set.spliterator();
		System.out.println(setSplIterator.getComparator());
		
	}

}
