package com.hp.test;

import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import com.hp.beans.Device;

//Java Reflection is a process of examining or modifying the 
//run time behavior of a class at run time.

//You can obtain the meta data of your class using reflection

public class ReflectionTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		Constructor con[] = Device.class.getDeclaredConstructors();
		
		Field fileds[] = Device.class.getDeclaredFields();
		
		
		Method method [] = Device.class.getDeclaredMethods();
		
		Annotation annotatins[] = Device.class.getDeclaredAnnotations();
		
		try {
			
			Device d = Device.class.newInstance(); // to create an instance
			
			Device d1 = Device.class.getDeclaredConstructor().newInstance();
			Field nameField = Device.class.getDeclaredField("name");
			nameField.setAccessible(true); // required only for private
			
			System.out.println(nameField.getModifiers() + " " + nameField.getType());
			
			Method deviceMethod = 
					Device.class.getDeclaredMethod("method1", new Class[] {Integer.class, String.class});
			
			deviceMethod.invoke(new Device(), new Object[] {1, "Abc"});
			
			
			
			
		} catch (NoSuchFieldException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
