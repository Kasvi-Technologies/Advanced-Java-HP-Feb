package com.hp.test;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class LockTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Runnable run = () -> {			
			Lock lock = new ReentrantLock();
			System.out.println("Before locking...");
			lock.lock();// lock is obtained on lock instance
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
			lock.unlock();			
		};
		
		Runnable run1 = () -> {			
			ReadWriteLock lock = new ReentrantReadWriteLock();
			System.out.println("Before locking...");
			lock.writeLock().lock();// lock is obtained on lock instance
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
			lock.writeLock().unlock();			
		};
		
		Runnable run2 = () -> {			
			ReadWriteLock lock = new ReentrantReadWriteLock();
			System.out.println("Before locking...");
			lock.readLock().lock();// lock is obtained on lock instance
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	finally {
				lock.readLock().unlock();
			}
						
		};
		
		
		
	}

}
