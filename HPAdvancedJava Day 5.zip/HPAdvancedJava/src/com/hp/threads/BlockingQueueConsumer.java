package com.hp.threads;

import java.util.concurrent.BlockingQueue;

import com.hp.beans.Message;

public class BlockingQueueConsumer implements Runnable{

	public BlockingQueueConsumer(BlockingQueue<Message> queue) {
		this.queue = queue;
	}
	
	private BlockingQueue<Message> queue;

	public void run() {		
		while(true) {
			try {
				Message message = queue.take();
				System.out.println("consumed message is: " + message.getMessage());
				
				if("Done".equals(message.getMessage())) {
					break;
				}
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
		}
			
	}
	

	
}
