package com.hp.threads;

import com.hp.beans.Employee;

//Runnable interface contains only run method.,
//it will not contain any other methods like start and setName methods..

public class MailRunnable implements Runnable {

	private Employee employee;
	
	public MailRunnable(Employee employee) {
		this.employee = employee;
	}
	
	public void run () {
		System.out.println("Mail Thread initiated..." + Thread.currentThread().getName());
		
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		employee.sendMail();
		
		System.out.println("Mail Thread completed....." + Thread.currentThread().getName());
		
	}
}
