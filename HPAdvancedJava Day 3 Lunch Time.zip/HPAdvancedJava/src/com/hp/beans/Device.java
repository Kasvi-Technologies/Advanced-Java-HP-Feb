package com.hp.beans;

public class Device {
	
	public Device() {
		
	}
	public Device(int id, String name, String model, String type, double price) {
		super();
		this.id = id;
		this.name = name;
		this.model = model;
		this.type = type;
		this.price = price;
	}
	private int id;
	private String name;
	private String model;
	private String type;
	private double price;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Device [id=" + id + ", name=" + name + ", model=" + model + ", type=" + type + ", price=" + price + "]";
	}

}
