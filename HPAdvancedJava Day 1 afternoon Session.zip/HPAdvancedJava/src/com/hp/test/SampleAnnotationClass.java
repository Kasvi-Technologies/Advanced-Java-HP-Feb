package com.hp.test;


@MyAnnotation(value="sample", age=25, colors= {"Red", "Blue"})
public class SampleAnnotationClass {

	@MyAnnotation(value="method", colors= {"Yellow", "Black"})
	public void add (String a, int b) {
		
	}
	
	public void add () {
		
	}
}


