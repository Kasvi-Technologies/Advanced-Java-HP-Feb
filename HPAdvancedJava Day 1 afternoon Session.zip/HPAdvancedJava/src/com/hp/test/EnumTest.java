package com.hp.test;

import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.hp.beans.Level;

public class EnumTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//System.out.println(Level.High);
		
		
		for (Level level : Level.values()) {
			System.out.println(level + " " + level.getLevel() );
			level.display();
			System.out.println(level.toLowercase());
		}
		
		System.out.println("Using enum Set.................");
		EnumSet<Level> enumSet = EnumSet.of(Level.High, Level.Medium);
		
		for (Level level : enumSet) {
			System.out.println(level + " " + level.getLevel() );
		}
		
		System.out.println("Using enum map.................");
		//Map m= new HashMap();
		
		EnumMap<Level, String  > enumMap = new EnumMap<Level, String>(Level.class);
		enumMap.put(Level.High, "High enum");
		enumMap.put(Level.Low, "Low enum");
		
		Set<Level> set = enumMap.keySet();
		for (Level level : set) {
			System.out.println(level + " " + level.getLevel() );
		}
		
		
	}

}
