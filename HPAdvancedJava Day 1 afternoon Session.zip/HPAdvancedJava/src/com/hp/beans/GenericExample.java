package com.hp.beans;

import java.util.List;

//public class ArrayList<Employee>

// E, T, K, V, S, U e.t.c
public class GenericExample<T > {

	private T val;

	//private S val1;
	
	public T getVal() {
		return val;
	}

	public void setVal(T val) {
		this.val = val;
	}
	
	
}
