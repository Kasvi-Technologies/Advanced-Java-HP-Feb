package com.hp.beans;

public class BankAccount {
	
	private int amount=1000;

	public int getAmount() {
		return amount;
	}

	//Synchronized method...
	
	public synchronized void insertAmount(int amount) {
		System.out.println(Thread.currentThread().getName() +" started.....");
		
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		this.amount = this.amount + amount;
		System.out.println(Thread.currentThread().getName() + "completed...");
	}
	

}
