package com.hp.test;

@interface Schedules {

	Schedule[] value();
}
