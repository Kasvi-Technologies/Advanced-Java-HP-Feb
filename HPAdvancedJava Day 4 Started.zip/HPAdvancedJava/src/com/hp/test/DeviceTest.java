package com.hp.test;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.hp.beans.Device;

/*
 * a. create a deviceLst with couple of Devices (like., laptop/TV e.t.c) make it atleast 10 devices
	b. Get the List of Devices whose type will be Laptop and name will be HP 
	c. Get all Distinct Types of Devices in List. Final Types List should be in Capital Letters
	d. Get the List of Devices whose type will be mobile and price is less than 10000
 */
public class DeviceTest {

	public static void main(String[] args) {
				List<Device> deviceLst = new ArrayList<Device>();
		Device d1 = new Device(1, "Hp", "X106", "Laptop", 50000);
		Device d2 = new Device(2, "Lenovo", "X390", "Laptop", 25000);
		Device d3 = new Device(3, "Samsung", "duo", "Mobile", 9000);
		Device d4 = new Device(4, "Samsung", "ABCD", "Tv", 30000);
		Device d5 = new Device(5, "Hp", "XYZ", "Laptop", 15000);
		deviceLst.add(d1);deviceLst.add(d2);deviceLst.add(d3);deviceLst.add(d4);deviceLst.add(d5);
		List<Device> filteredLst1 = deviceLst.stream()
									.filter(d -> d.getName().equals("Hp") && d.getType().equals("Laptop"))
									.collect(Collectors.toList());
		System.out.println(filteredLst1);
		List<String> distinctTypes = deviceLst.stream().map(d -> d.getType().toUpperCase()).distinct()
											.collect(Collectors.toList());
		System.out.println(distinctTypes);
		List<Device> filteredLst2 = deviceLst.stream()
									.filter(d -> d.getPrice()<10000 && d.getType().equals("Mobile"))
									.collect(Collectors.toList());
		System.out.println(filteredLst2);
	}

}
