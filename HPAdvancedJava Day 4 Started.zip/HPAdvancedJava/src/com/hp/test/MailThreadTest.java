package com.hp.test;

import com.hp.beans.Employee;
import com.hp.threads.MailRunnable;
import com.hp.threads.MailThread;

public class MailThreadTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MailThread thread1 = new MailThread(new Employee(1, "Abc",  50000));
		thread1.setName("Mail Thread1");
		MailThread thread2 = new MailThread(new Employee(2, "Def", 20000));
		thread2.setName("Mail Thread2");
		
		thread1.start();
		thread2.start();
		
		//Runnable Interfaces
		MailRunnable m = new MailRunnable(new Employee(3, "Using Runnable",  50000));
		MailRunnable m1 = new MailRunnable(new Employee(4, "Using Runnable1",  25000));
		
		Thread t = new Thread(m, "firstmailrunnable");
		//t.setName()
		
		Thread t1 = new Thread(m1 , "secondmailrunnable");
		t.start();
		t1.start();
		
		//you can call run method explicitly., but that will act like a normal method.. (non-asynchronous)
		//thread1.run()
		//t.run()
		
	}

}
