package com.hp.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class FilesNewFeaturesTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * Files.list()
		Files.lines()
		Files.find()
		BufferedReader.lines()

		 */
		
		try {
			
			Stream<Path> filesLst = Files.list(Paths.get("."));
			filesLst.filter(path -> path.toString().endsWith("jar")).forEach(System.out::println);
			
			Stream<String> fileLines = Files.lines(Paths.get("C:/anil/sample.txt"));
			System.out.println("Sample File Lines....");
			fileLines.forEach(System.out::println);
			
			BufferedReader br = Files.newBufferedReader(Paths.get("C:/anil/sample.txt"));
			
			br.lines().forEach(System.out::println);;
			
			System.out.println("Dir PAths..");
			Stream<Path> dirPath = 
					Files.find(Paths.get("."), Integer.MAX_VALUE, 
							(path, attrs) ->attrs.isDirectory() || attrs.isRegularFile());
			
			
			dirPath.forEach(System.out::println);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
